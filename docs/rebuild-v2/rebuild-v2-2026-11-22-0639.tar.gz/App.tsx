import React, { useEffect, useMemo, useRef, useState } from "react";
import { BookOpen, Search, Plus, Copy, Download, Upload, PenLine, ChevronDown, ChevronRight, AlertTriangle, Check } from "lucide-react";
import seedData from "./assets/319c62492332fd26-bookshelf_seed.json";

type Book = { id:string; shelf:number; title:string; author?:string; publisher?:string; year?:string; isbn?:string; ebook?:string; pinned?:boolean; quote?:string; pages?:string; impression?:string; contexts?:string[]; related?:string[]; badge?:string; volumes?:string };
type Want = { id:number|string; title:string; author?:string; prime?:boolean; ku?:boolean; price?:string; link?:string; memo?:string; status?:string };
type Ctx = { id:number|string; quote:string; source:string; draft?:string; note?:string };
type Draft = { id:string; title:string; created:string; quote:string; source:string; impression:string; body:string };
type ActionCandidate = { id:string; title:string; author:string; publisher:string; shelf:number; row:string; position:string; checked:boolean; unparsed:boolean; raw:string };

const seed = seedData as { books:Book[]; shelves:{n:number;title:string;count:number;note:string}[]; contexts:Ctx[]; want:Want[] };
const clone = <T,>(v:T):T => JSON.parse(JSON.stringify(v));
const normTitle = (s="") => s.normalize("NFKC").toLowerCase().replace(/[\s　\-―ー・.,;:!?()（）「」『』"']/g,"").replace(/[^a-z0-9\u3040-\u30ff\u4e00-\u9fff]/g,"");
const normIsbn = (s="") => s.replace(/[^0-9Xx]/g,"").toUpperCase();
const volOf = (b:Book) => (b.volumes && b.volumes.includes("18") ? 18 : 1);
const fmtTime = (d:Date) => `${d.getMonth()+1}/${d.getDate()} ${String(d.getHours()).padStart(2,"0")}:${String(d.getMinutes()).padStart(2,"0")}`;
const emptyBook = (shelf=1):Book => ({ id:"", shelf, title:"", author:"", publisher:"", year:"", isbn:"", ebook:"要確認", pinned:false, quote:"", pages:"", impression:"", contexts:[], related:[] });
async function callRecords(action:string, args:any){
  const res = await fetch("actions", {method:"POST", headers:{"content-type":"application/json"}, body: JSON.stringify({action, args})});
  const json:any = await res.json().catch(()=>({}));
  if(!res.ok || json.error) throw new Error(json.error || `records API error (${res.status})`);
  return json.data;
}

// 開発者向けコメント：開発者の Github は https://github.com/rayvisionkobe-collab/bookshelf（今は公開、アプリ公開時はプライベートにする予定）。画面には表示しない。
// 開発者用設定：エンドユーザーには画面に表示しない。Github は開発者（アプリを作る人）のもの。
// owner / repo は確定済み。token は未設定のままでは送信しない。
const DEVELOPER_REPO = { owner: "rayvisionkobe-collab", repo: "bookshelf", workflow: "ocr.yml", token: "" };
// 開発者リポジトリの URL。画面には表示しない（下の sr-only 要素でビルド成果物に残す）。
const DEVELOPER_REPO_URL = "https://github.com/rayvisionkobe-collab/bookshelf";

function Field({label,children}:{label:string;children:React.ReactNode}){ return <div className="field"><label>{label}</label>{children}</div> }
function EbookChip({v}:{v?:string}){ return <span className="chip">電子版：{v||"—"}</span> }

export default function App(){
  const [books,setBooks]=useState<Book[]>(()=>clone(seed.books));
  const [want,setWant]=useState<Want[]>(()=>clone(seed.want));
  const [contexts,setContexts]=useState<Ctx[]>(()=>clone(seed.contexts));
  const [drafts,setDrafts]=useState<Draft[]>([]);
  const [tab,setTab]=useState("棚");
  const [lastEdit,setLastEdit]=useState<Date|null>(null);
  const touch=()=>setLastEdit(new Date());
  const [notice,setNotice]=useState("");
  const [search,setSearch]=useState("");
  const [fEbook,setFEbook]=useState("すべて");
  const [fShelf,setFShelf]=useState("すべて");
  const [fView,setFView]=useState("すべて");
  const [collapsed,setCollapsed]=useState<Record<number,boolean>>({1:false,2:false,3:false});
  const [selectedId,setSelectedId]=useState<string|null>("b2");
  const [showAdd,setShowAdd]=useState(false);
  const [addForm,setAddForm]=useState<Book>(()=>emptyBook(1));
  const [addWarn,setAddWarn]=useState<string|null>(null);
  const [addConfirmed,setAddConfirmed]=useState(false);
  const [editForm,setEditForm]=useState<Book|null>(null);
  const [wantForm,setWantForm]=useState<Want>({id:"",title:"",author:"",prime:false,ku:false,price:"",link:"",memo:"",status:"読みたい"});
  const [wantEdit,setWantEdit]=useState<Want|null>(null);
  const [wantWarn,setWantWarn]=useState<string|null>(null);
  const [wantConfirmed,setWantConfirmed]=useState(false);
  const [moveShelf,setMoveShelf]=useState<Record<string,number>>({});
  const [moveWarn,setMoveWarn]=useState<string|null>(null);
  const [ctxForm,setCtxForm]=useState<Ctx>({id:"",quote:"",source:"",draft:"",note:""});
  const [ctxEdit,setCtxEdit]=useState<Ctx|null>(null);
  const [draftTitle,setDraftTitle]=useState("ネオ行政国家論から、行政書士実務メモへ");
  const [draftQuote,setDraftQuote]=useState("");
  const [draftSource,setDraftSource]=useState("");
  const [draftImpr,setDraftImpr]=useState("");
  const [draftBody,setDraftBody]=useState("");
  const [editingDraftId,setEditingDraftId]=useState<string|null>(null);
  const [exportText,setExportText]=useState("");
  const [importText,setImportText]=useState("");
  const [confirmReset,setConfirmReset]=useState(false);
  const [confirmDelete,setConfirmDelete]=useState<string|null>(null);
  const [persistLoaded,setPersistLoaded]=useState(false);
  const [persistStatus,setPersistStatus]=useState("読み込み中…");
  const [persistError,setPersistError]=useState<string|null>(null);
  const recordMapRef=useRef<Record<string,string>>({});
  const tombstoneRef=useRef<Set<string>>(new Set());
  const snapshotRef=useRef<{books:Book[];want:Want[];contexts:Ctx[];drafts:Draft[]}|null>(null);
  const syncingRef=useRef(false);
  const syncQueuedRef=useRef(false);

  // 取り込む（B方式：Github Actions経由）
  const [photoMode,setPhotoMode]=useState<"file"|"cloud">("file");
  const [photoUrl,setPhotoUrl]=useState("");
  const [photoName,setPhotoName]=useState("");
  const [cloudProvider,setCloudProvider]=useState("Google Drive");
  const [cloudUrl,setCloudUrl]=useState("");
  const [importShelf,setImportShelf]=useState(1);
  const [importRow,setImportRow]=useState("上段");
  const [ghMsg,setGhMsg]=useState("");
  const [ghSending,setGhSending]=useState(false);
  const [actionsJson,setActionsJson]=useState("");
  const [actionsCandidates,setActionsCandidates]=useState<ActionCandidate[]>([]);
  const [actionsMsg,setActionsMsg]=useState("");
  const [manualRows,setManualRows]=useState<{id:string;title:string;author:string}[]>([{id:`m${Date.now()}`,title:"",author:""}]);
  const [manualMsg,setManualMsg]=useState("");
  const aiPrompt="これは、私の本棚の写真です。ここに写っている書籍のタイトルや著者名・出版社を、左から右へ番号付きで教えてください。左から何番目かも一緒に教えてください。形式は『タイトル』 著者：名前 / 出版社 でお願いします。読めない本は「読めませんでした」と書いてください。";
  const [aiPaste,setAiPaste]=useState("");
  const [aiCandidates,setAiCandidates]=useState<{id:string;title:string;author:string;publisher:string;checked:boolean;unparsed:boolean;raw:string}[]>([]);
  const [aiShelf,setAiShelf]=useState(1);
  const [aiMsg,setAiMsg]=useState("");
  const aiPromptRef=useRef<HTMLTextAreaElement>(null);
  const [isbnInput,setIsbnInput]=useState("");
  const [isbnMsg,setIsbnMsg]=useState("");
  const [isbnForm,setIsbnForm]=useState({title:"",author:"",publisher:"",year:""});
  const fileRef=useRef<HTMLInputElement>(null);
  const importFileRef=useRef<HTMLInputElement>(null);
  const copyRef=useRef<HTMLTextAreaElement>(null);

  const copyAiPrompt=()=>{ if(!aiPromptRef.current) return; aiPromptRef.current.value=aiPrompt; aiPromptRef.current.select(); document.execCommand("copy"); setAiMsg("プロンプトをコピーしました。"); };
  const parseAiPaste=(text:string)=>{
    const cleaned=text.replace(/\*\*/g,"");
    const lines=cleaned.split(/\r?\n/);
    const out:{id:string;title:string;author:string;publisher:string;checked:boolean;unparsed:boolean;raw:string}[]=[];
    let current:{id:string;title:string;author:string;publisher:string;checked:boolean;unparsed:boolean;raw:string}|null=null;
    const pushCurrent=()=>{ if(current) out.push(current); current=null; };
    lines.forEach((rawLine,idx)=>{
      let line=rawLine.trim();
      if(!line) return;
      if(/^---+$/.test(line)) return;
      const numbered=/^\d+\s*[.\)、．]\s*/.test(line);
      line=line.replace(/^#{1,6}\s*/,"").replace(/^\d+\s*[.\)、．]\s*/,"").replace(/^[-•・*]\s*/,"").trim();
      if(!line) return;
      const titleMatch=line.match(/[『「]([^』」]+)[』」]/);
      if(titleMatch){
        pushCurrent();
        let title=titleMatch[1].trim();
        const rest=line.slice(line.indexOf(titleMatch[0])+titleMatch[0].length).trim();
        let author=""; let publisher=""; let subtitle="";
        let str=rest;
        const subMatch=str.match(/副題\s*[:：]\s*([^\/／]+?)(?=\s*(著者|著|編|\/|／|$))/);
        if(subMatch){ subtitle=subMatch[1].trim(); str=str.replace(subMatch[0],""); }
        const authorMatch=str.match(/(著者|編著|編|著)\s*[:：]\s*([^\/／]+?)(?=\s*[\/／]|$)/);
        if(authorMatch){ author=authorMatch[2].trim().replace(/[。、，,]+$/,""); str=str.replace(authorMatch[0],""); }
        const pubMatch=str.match(/[\/／]\s*(.+)$/);
        if(pubMatch){ publisher=pubMatch[1].trim().replace(/[。、]+$/,""); }
        if(subtitle) title=`${title}：${subtitle}`;
        current={id:`ai${Date.now()}-${idx}-${out.length}`,title,author,publisher,checked:true,unparsed:false,raw:rawLine.trim()};
        return;
      }
      if(current && /(副題|著者|著|編|出版社|出版|読めませんでした)/.test(line)){
        let str=line;
        const subMatch=str.match(/副題\s*[:：]\s*([^\/／]+?)(?=\s*(著者|著|編|\/|／|$))/);
        if(subMatch && !current.title.includes("：")){ current.title=`${current.title}：${subMatch[1].trim()}`; str=str.replace(subMatch[0],""); }
        const authorMatch=str.match(/(著者|編著|編|著)\s*[:：]\s*([^\/／]+?)(?=\s*[\/／]|$)/);
        if(authorMatch && !current.author){ current.author=authorMatch[2].trim().replace(/[。、，,]+$/,""); str=str.replace(authorMatch[0],""); }
        const pubMatch=str.match(/[\/／]\s*(.+)$/);
        if(pubMatch && !current.publisher){ current.publisher=pubMatch[1].trim().replace(/[。、]+$/,""); }
        return;
      }
      if(numbered){
        pushCurrent();
        current={id:`ai${Date.now()}-${idx}-u`,title:line,author:"",publisher:"",checked:false,unparsed:true,raw:rawLine.trim()};
        return;
      }
    });
    pushCurrent();
    return out;
  };
  const buildAiCandidates=()=>{
    if(!aiPaste.trim()){ setAiMsg("AIの返答を貼ってください。"); return; }
    const parsed=parseAiPaste(aiPaste);
    if(!parsed.length){ setAiMsg("候補が見つかりませんでした。『タイトル』を含む形式で貼り直してください。"); return; }
    setAiCandidates(parsed);
    const failed=parsed.filter(c=>c.unparsed).length;
    setAiMsg(`${parsed.length}件の候補を作りました。${failed?`${failed}件はパースできませんでした。手で直してください。`:""}タイトル・著者・出版社を確認してから追加してください。`);
  };
  const addAiCandidates=()=>{
    const chosen=aiCandidates.filter(c=>c.checked && c.title.trim());
    let added=0; let skipped=0;
    const next=[...books];
    for(const c of chosen){
      const dup=dupFor(c.title,"");
      if(dup.inBooks||dup.inWant){ skipped++; continue; }
      next.push({id:`ai${Date.now()}-${added}-${Math.floor(Math.random()*1000)}`,shelf:aiShelf,title:c.title.trim(),author:c.author.trim(),publisher:c.publisher.trim(),year:"",isbn:"",ebook:"要確認"});
      added++;
    }
    setBooks(next); touch();
    setAiMsg(added?`${added}件を棚${aiShelf}に追加しました。${skipped?`${skipped}件は重複のため追加していません。`:""}`:"追加できる新規候補がありませんでした。重複は追加していません。");
    if(added) setAiCandidates(prev=>prev.map(c=>chosen.some(x=>x.id===c.id)?{...c,checked:false}:c));
  };

  // クラウドURL → 直ダウンロードURL
  const directUrlInfo=useMemo(()=>{
    const url=cloudUrl.trim();
    if(!url) return {direct:"", note:""};
    if(cloudProvider==="Google Drive"){
      const m=url.match(/\/file\/d\/([^/?#]+)/) || url.match(/[?&]id=([^&#]+)/);
      if(m) return {direct:`https://drive.google.com/uc?export=download&id=${m[1]}`, note:"「リンクを知っている全員」にしておいてください。"};
      return {direct:"", note:"Google Drive の共有リンク（drive.google.com/file/d/FILE_ID/view 形式）を貼ってください。"};
    }
    if(cloudProvider==="Dropbox"){
      if(!url.includes("dropbox.com")) return {direct:"", note:"Dropbox の共有リンク（dropbox.com/s/... 形式）を貼ってください。"};
      let direct=url;
      if(direct.includes("dl=0")) direct=direct.replace("dl=0","dl=1");
      else if(direct.includes("?")) direct=`${direct}&dl=1`;
      else direct=`${direct}?dl=1`;
      return {direct, note:""};
    }
    return {direct:"", note:"このリンクは Actions 側から直接落とせません。ファイルを直接選んでください。"};
  },[cloudUrl, cloudProvider]);
  const cloudUnsupported = (cloudProvider==="iCloud" || cloudProvider==="Amazon Photos") && !!cloudUrl.trim();

  const handlePhoto=(f:File|undefined)=>{ if(!f) return; setPhotoUrl(URL.createObjectURL(f)); setPhotoName(f.name); setNotice("写真をこの画面で表示しました。AIに送るを押した写真だけ、認識のために外部に送ります。"); };

  const sendToActions=async()=>{
    setGhMsg("");
    if(!DEVELOPER_REPO.owner || !DEVELOPER_REPO.repo || !DEVELOPER_REPO.workflow || !DEVELOPER_REPO.token){
      setGhMsg("開発者の Github 側の設定がまだです");
      return;
    }
    if(photoMode==="file"){
      setGhMsg("ファイルは直接送りません。URLに変換してから送ってください。クラウドに上げた写真の直ダウンロードURLを「クラウドのURLを貼る」で貼ってから、もう一度送ってください。");
      return;
    }
    if(cloudUnsupported){
      setGhMsg("このリンクは Actions 側から直接落とせません。ファイルを直接選んでください。");
      return;
    }
    if(!directUrlInfo.direct){
      setGhMsg("直ダウンロードURLを作れませんでした。クラウドの共有リンクを貼り直してください。");
      return;
    }
    // 外部（GitHub API）への直接送信は行わない。B方式は、結果 JSON を貼って候補を確認する流れを使う。
    // 開発者リポジトリ（DEVELOPER_REPO_URL）は画面に表示しない。
    void DEVELOPER_REPO_URL;
    setGhMsg("Actions への自動送信はこの画面からは行いません。直ダウンロードURLと棚・段を確認したら、Actions の結果 JSON を下の欄に貼って候補を確認してください。");
  };

  const buildActionsCandidates=()=>{
    const text=actionsJson.trim();
    if(!text){ setActionsMsg("Actions の結果 JSON または AIの返答テキストを貼ってください。"); return; }
    let parsedJson:any=null;
    try{ parsedJson=JSON.parse(text); }catch{ parsedJson=null; }
    if(parsedJson){
      const arr=Array.isArray(parsedJson) ? parsedJson : (Array.isArray(parsedJson.books) ? parsedJson.books : Array.isArray(parsedJson.results) ? parsedJson.results : Array.isArray(parsedJson.candidates) ? parsedJson.candidates : null);
      if(!arr){ setActionsMsg("JSONの配列が見つかりませんでした。[{title, author, publisher, shelf, row, position}] の配列で貼ってください。"); return; }
      const mapped:ActionCandidate[]=arr.map((r:any,idx:number)=>{
        const shelfNum=typeof r.shelf==="number" ? r.shelf : Number(r.shelf) || importShelf;
        const rowVal=typeof r.row==="string" && r.row ? r.row : importRow;
        const posVal=r.position!==undefined && r.position!==null ? String(r.position) : (r.index!==undefined && r.index!==null ? String(r.index) : "");
        return {id:`act${Date.now()}-${idx}`, title:String(r.title||"").trim(), author:String(r.author||"").trim(), publisher:String(r.publisher||"").trim(), shelf:shelfNum>=1&&shelfNum<=3?shelfNum:importShelf, row:rowVal, position:posVal, checked:!!String(r.title||"").trim(), unparsed:!String(r.title||"").trim(), raw:JSON.stringify(r)};
      });
      const usable=mapped.filter(c=>c.title);
      if(!usable.length){ setActionsMsg("タイトルがある候補が見つかりませんでした。"); return; }
      setActionsCandidates(mapped);
      setActionsMsg(`${mapped.length}件の候補を作りました。タイトル・著者・出版社・棚・段・左から何番目を確認してから追加してください。`);
      return;
    }
    const parsed=parseAiPaste(text);
    if(!parsed.length){ setActionsMsg("候補が見つかりませんでした。JSONの配列か、『タイトル』を含むAI返答テキストで貼り直してください。"); return; }
    setActionsCandidates(parsed.map((c,idx)=>({id:c.id, title:c.title, author:c.author, publisher:c.publisher, shelf:importShelf, row:importRow, position:String(idx+1), checked:c.checked, unparsed:c.unparsed, raw:c.raw})));
    setActionsMsg(`${parsed.length}件の候補を作りました（AI返答テキストとしてパースしました）。タイトル・著者・出版社・棚・段・左から何番目を確認してから追加してください。`);
  };
  const addActionsCandidates=()=>{
    const chosen=actionsCandidates.filter(c=>c.checked && c.title.trim());
    let added=0; let skipped=0;
    const next=[...books];
    for(const c of chosen){
      const dup=dupFor(c.title,"");
      if(dup.inBooks||dup.inWant){ skipped++; continue; }
      next.push({id:`act${Date.now()}-${added}-${Math.floor(Math.random()*1000)}`,shelf:c.shelf,title:c.title.trim(),author:c.author.trim(),publisher:c.publisher.trim(),year:"",isbn:"",ebook:"要確認"});
      added++;
    }
    setBooks(next); touch();
    setActionsMsg(added?`${added}件を蔵書に追加しました。${skipped?`${skipped}件は重複のため追加していません。`:""}`:"追加できる新規候補がありませんでした。重複は追加していません。");
    if(added) setActionsCandidates(prev=>prev.map(c=>chosen.some(x=>x.id===c.id)?{...c,checked:false}:c));
  };

  const addManualRow=(row:{id:string;title:string;author:string})=>{
    if(!row.title.trim()){ setManualMsg("タイトルを入れてください。"); return; }
    const dup=dupFor(row.title,"");
    if(dup.inBooks||dup.inWant){ setManualMsg(`『${row.title}』はすでに${dup.inBooks?`棚${dup.inBooks.shelf}`:"読みたいリスト"}にあります。重複は追加していません。`); return; }
    const nb:Book={id:`man${Date.now()}-${Math.floor(Math.random()*1000)}`,shelf:importShelf,title:row.title.trim(),author:row.author.trim(),publisher:"",year:"",isbn:"",ebook:"要確認"};
    setBooks(p=>[...p,nb]); touch(); setManualMsg(`『${row.title}』を棚${importShelf}に追加しました。`); setNotice(`『${row.title}』を棚${importShelf}に追加しました。`);
    setManualRows(prev=>prev.map(x=>x.id===row.id?{...x,title:"",author:""}:x));
  };

  const totalVol=useMemo(()=>books.reduce((a,b)=>a+volOf(b),0),[books]);
  const pinned=books.filter(b=>b.pinned);
  const dupFor=(title:string,isbn:string,excludeId?:string)=>{
    const t=normTitle(title), i=normIsbn(isbn);
    const inBooks=books.find(b=>b.id!==excludeId && ((t&&normTitle(b.title)===t)||(i&&normIsbn(b.isbn||"")===i&&i.length>=10)));
    const inWant=want.find(w=>t&&normTitle(w.title)===t);
    return {inBooks,inWant};
  };
  const filtered=useMemo(()=>{
    const q=search.trim().toLowerCase();
    return books.filter(b=>{
      if(q && !(`${b.title} ${b.author||""} ${b.publisher||""}`).toLowerCase().includes(q)) return false;
      if(fEbook!=="すべて"&&b.ebook!==fEbook) return false;
      if(fShelf!=="すべて"&&b.shelf!==Number(fShelf)) return false;
      if(fView==="よく使うのみ"&&!b.pinned) return false;
      if(fView==="重複のみ"){
        const others=books.filter(x=>x.id!==b.id);
        const dup=others.some(x=>normTitle(x.title)===normTitle(b.title)||(normIsbn(x.isbn||"")&&normIsbn(x.isbn||"")===normIsbn(b.isbn||"")));
        if(!dup) return false;
      }
      return true;
    });
  },[books,search,fEbook,fShelf,fView]);
  const selected=books.find(b=>b.id===selectedId)||null;
  // 永続化：読み込み（records.list）— APIが使えない場合はシードのまま動き、落ちない
  useEffect(()=>{
    let alive=true;
    (async()=>{
      try{
        const [bRes,wRes,cRes,dRes,tRes]=await Promise.all([
          callRecords("records.list",{collection:"books",limit:100}),
          callRecords("records.list",{collection:"want",limit:100}),
          callRecords("records.list",{collection:"contexts",limit:100}),
          callRecords("records.list",{collection:"drafts",limit:100}),
          callRecords("records.list",{collection:"tombstones",limit:100}),
        ]);
        if(!alive) return;
        const tombs=new Set<string>((tRes?.records||[]).map((r:any)=>String(r.value?.entityId||"")));
        tombstoneRef.current=tombs;
        const map:Record<string,string>={};
        const loadedBooks:Book[]=(bRes?.records||[]).map((r:any)=>{ map[`books:${String(r.value?.id)}`]=r.id; return r.value; });
        const wantVals:Want[]=(wRes?.records||[]).map((r:any)=>{ map[`want:${String(r.value?.id)}`]=r.id; return r.value; });
        const ctxVals:Ctx[]=(cRes?.records||[]).map((r:any)=>{ map[`contexts:${String(r.value?.id)}`]=r.id; return r.value; });
        const draftVals:Draft[]=(dRes?.records||[]).map((r:any)=>{ map[`drafts:${String(r.value?.id)}`]=r.id; return r.value; });
        const bookVals:Book[]=loadedBooks;
        recordMapRef.current=map;
        const nextBooks = bookVals.length? bookVals.filter(b=>!tombs.has(`books:${b.id}`)) : clone(seed.books).filter(b=>!tombs.has(`books:${b.id}`));
        const nextWant = wantVals.length? wantVals.filter(w=>!tombs.has(`want:${String(w.id)}`)) : clone(seed.want).filter(w=>!tombs.has(`want:${String(w.id)}`));
        const nextCtx = ctxVals.length? ctxVals.filter(c=>!tombs.has(`contexts:${String(c.id)}`)) : clone(seed.contexts).filter(c=>!tombs.has(`contexts:${String(c.id)}`));
        const nextDrafts = draftVals;
        snapshotRef.current={books:clone(nextBooks),want:clone(nextWant),contexts:clone(nextCtx),drafts:clone(nextDrafts)};
        if(bookVals.length) setBooks(nextBooks);
        if(wantVals.length) setWant(nextWant);
        if(ctxVals.length) setContexts(nextCtx);
        if(draftVals.length) setDrafts(nextDrafts);
        setPersistStatus("保存済み"); setPersistError(null);
      }catch(e){
        if(!alive) return;
        snapshotRef.current={books:clone(seed.books),want:clone(seed.want),contexts:clone(seed.contexts),drafts:[]};
        setPersistStatus("保存に接続できませんでした"); setPersistError(e instanceof Error?e.message:String(e));
      }finally{ if(alive) setPersistLoaded(true); }
    })();
    return ()=>{ alive=false; };
  },[]);
  // 永続化：差分だけ records.create / records.replace / records.delete する
  useEffect(()=>{
    if(!persistLoaded || !snapshotRef.current) return;
    const sync=async()=>{
      if(syncingRef.current){ syncQueuedRef.current=true; return; }
      syncingRef.current=true; setPersistStatus("保存中…");
      let error:string|null=null;
      try{
        const snap=snapshotRef.current!;
        const syncOne=async(collection:string, cur:any[], prev:any[])=>{
          const prevById=new Map(prev.map(x=>[String(x.id),x]));
          const curById=new Map(cur.map(x=>[String(x.id),x]));
          let saved=0;
          for(const row of cur){
            const key=`${collection}:${String(row.id)}`;
            const old=prevById.get(String(row.id));
            const changed=!old || JSON.stringify(old)!==JSON.stringify(row);
            if(!changed) continue;
            const recId=recordMapRef.current[key];
            const idempotency_key=`create-${collection}-${String(row.id)}`;
            if(recId){ await callRecords("records.replace",{collection,id:recId,value:row}); }
            else { const created:any=await callRecords("records.create",{collection,value:row,idempotency_key}); if(created?.id) recordMapRef.current[key]=created.id; }
            saved+=1;
          }
          for(const old of prev){
            if(curById.has(String(old.id))) continue;
            const key=`${collection}:${String(old.id)}`;
            const recId=recordMapRef.current[key];
            if(recId){ await callRecords("records.delete",{collection,id:recId}); delete recordMapRef.current[key]; }
            else if(!tombstoneRef.current.has(key)){
              const created:any=await callRecords("records.create",{collection:"tombstones",value:{entityId:key,collection},idempotency_key:`tomb-${key}`});
              if(created?.id) recordMapRef.current[`tombstones:${key}`]=created.id;
              tombstoneRef.current.add(key);
            }
          }
          void saved;
        };
        await syncOne("books",books,snap.books);
        await syncOne("want",want,snap.want);
        await syncOne("contexts",contexts,snap.contexts);
        await syncOne("drafts",drafts,snap.drafts);
        snapshotRef.current={books:clone(books),want:clone(want),contexts:clone(contexts),drafts:clone(drafts)};
        setPersistStatus("保存済み"); setPersistError(null);
      }catch(e){ error=e instanceof Error?e.message:String(e); setPersistStatus("保存に失敗しました"); setPersistError(error); }
      syncingRef.current=false;
      if(syncQueuedRef.current){ syncQueuedRef.current=false; void sync(); }
    };
    void sync();
  },[books,want,contexts,drafts,persistLoaded]);

  const saveAdd=(form:Book)=>{
    const dup=dupFor(form.title,form.isbn||"");
    if(!addConfirmed && (dup.inBooks||dup.inWant)){
      setAddWarn(`『${form.title}』はすでに${dup.inBooks?`棚${dup.inBooks.shelf}`:"読みたいリスト"}にあります。重複して買いますか？`);
      return;
    }
    const nb={...form,id:`b${Date.now()}`,contexts:form.contexts||[],related:form.related||[]};
    setBooks(p=>[...p,nb]); setAddForm(emptyBook(1)); setAddWarn(null); setAddConfirmed(false); setShowAdd(false); setSelectedId(nb.id); touch(); setNotice(`『${form.title}』を棚${form.shelf}に追加しました（この画面だけの変更です）。`);
  };
  const saveEdit=()=>{
    if(!editForm) return;
    setBooks(p=>p.map(b=>b.id===editForm.id?editForm:b)); setEditForm(null); touch(); setNotice("書誌を更新しました。");
  };
  const startDraftFromBook=(b:Book)=>{
    setDraftTitle(`${b.title}から、メモへ`); setDraftQuote(b.quote||""); setDraftSource(b.title); setDraftImpr(b.impression||""); setDraftBody(`『${b.title}』（${b.author||""}／${b.publisher||""}）を読んで。\n\n`); setEditingDraftId(null); setTab("note下書き"); setNotice("note下書きのエディタに本の内容を入れました。");
  };
  const startDraftFromCtx=(c:Ctx)=>{
    setDraftTitle(`${c.draft||"文脈"}へのメモ`); setDraftQuote(c.quote); setDraftSource(c.source); setDraftImpr(c.note||""); setDraftBody(""); setEditingDraftId(null); setTab("note下書き");
  };
  const saveDraft=()=>{
    if(!draftTitle.trim()){ setNotice("下書きのタイトルを入れてください。"); return; }
    const d:Draft={id:editingDraftId||`d${Date.now()}`,title:draftTitle,created:fmtTime(new Date()),quote:draftQuote,source:draftSource,impression:draftImpr,body:draftBody};
    if(editingDraftId) setDrafts(p=>p.map(x=>x.id===editingDraftId?d:x)); else setDrafts(p=>[d,...p]);
    setEditingDraftId(null); touch(); setNotice("下書きを保存しました（この画面だけ）。");
  };
  const copyDraft=()=>{
    const text=`${draftTitle}\n\n「${draftQuote}」\n出典：${draftSource}\n\n${draftBody}\n\n感想：${draftImpr}`;
    copyRef.current!.value=text; copyRef.current!.select(); document.execCommand("copy"); setNotice("下書きをコピーしました。");
  };
  const doExport=()=>{
    const data=JSON.stringify({books,want,contexts,drafts,exportedAt:new Date().toISOString()},null,2);
    setExportText(data);
    const blob=new Blob([data],{type:"application/json"}); const url=URL.createObjectURL(blob); const a=document.createElement("a"); a.href=url; a.download="bookshelf-rebuild-v2.json"; a.click(); setTimeout(()=>URL.revokeObjectURL(url),1000); setNotice("JSONを書き出しました。");
  };
  const doImport=(text:string)=>{
    try{ const d=JSON.parse(text); if(!Array.isArray(d.books)) throw new Error("books がありません"); setBooks(d.books); if(Array.isArray(d.want)) setWant(d.want); if(Array.isArray(d.contexts)) setContexts(d.contexts); if(Array.isArray(d.drafts)) setDrafts(d.drafts); touch(); setNotice("JSONを読み込みました（この画面だけ）。"); }
    catch{ setNotice("読み込めませんでした。books を含むJSONか確認してください。"); }
  };
  const checkIsbn=()=>{ const n=normIsbn(isbnInput); if(n.length!==10&&n.length!==13){ setIsbnMsg("ISBNは10桁または13桁で入れてください（ハイフン可）。"); return; } const dup=books.find(b=>normIsbn(b.isbn||"")===n); if(dup){ setIsbnMsg(`このISBNはすでに棚${dup.shelf}の『${dup.title}』と一致します。`); } else { setIsbnMsg("外部への問い合わせはしません。書誌は下の手入力欄で補完してください。"); } };

  const tabs=["棚","取り込む","読みたい","文脈","note下書き"];
  const ebookOpts=["すべて","あり","なし","要確認","ありそう"];

  return <div data-safe-area-inset-root className="min-h-screen" style={{background:"var(--paper)",color:"var(--ink)",boxSizing:"border-box",paddingTop:"var(--safe-area-inset-top)"}}>
    <div className="mx-auto max-w-[1080px] px-4 sm:px-6 pb-10">
      <header className="pt-7 pb-5 border-b" style={{borderColor:"var(--line)"}}>
        <div className="flex flex-wrap items-end justify-between gap-4">
          <div>
            <p className="text-[12px] tracking-[0.22em] mb-2" style={{color:"var(--accent)"}}>REBUILD v2 ・ LOCAL NOTEBOOK</p>
            <h1 className="serif font-bold leading-tight" style={{fontSize:"clamp(28px,5vw,42px)"}}>本棚リサーチ手帳</h1>
            <div className="mt-4 p-4 sm:p-5 rounded-xl border-2" style={{borderColor:"var(--accent)",background:"var(--accent-soft)"}} role="note" aria-label="このRebuild V2の対象者について">
              <p className="text-[12px] font-bold tracking-[0.18em]" style={{color:"var(--accent)"}}>この REBUILD V2 は誰用？ — 開発者用です</p>
              <p className="serif font-bold leading-relaxed mt-2 [overflow-wrap:anywhere]" style={{fontSize:"clamp(18px,3.6vw,24px)"}}>これは開発者（ray.vision.kobe / Tsuyoshi Mutoh）用のリサーチ手帳・仕様メモです。エンドユーザー向けの本棚アプリそのものではありません。</p>
              <ul className="mt-3 space-y-2 text-sm sm:text-base leading-relaxed list-disc pl-5 [overflow-wrap:anywhere]">
                <li>ここには開発者だけが知ればいいことが入っています：Github の Secrets、API キーの扱い、A/B/C の料金の考え方、無料枠の切り分け、AI Studio の操作手順など。エンドユーザーには見せません。</li>
                <li>エンドユーザー向けの本棚アプリは別で、静かで、評価やランキングや通知がなく、プライベートが基本です。そのアプリには開発者用の話は出しません。</li>
              </ul>
            </div>
            <p className="mt-3 text-sm leading-relaxed" style={{color:"var(--muted)"}}>静かで、ローカル完結な蔵書リサーチ手帳。評価・ランキング・通知なし。<br className="hidden sm:block"/>非公開が基本。共有は、選んだものだけ。</p>
          </div>
          <div className="card p-3 text-sm min-w-[240px]">
            <p><span className="inline-block w-2 h-2 rounded-full mr-2" style={{background:"var(--ok)"}}/>この画面の中だけで保存</p>
            <p className="text-xs mt-1" style={{color:"var(--muted)"}}>保存：{persistStatus}{persistError?` — ${persistError}`:""}・最終編集：{lastEdit?fmtTime(lastEdit):"まだなし"}</p>
            <p className="mt-2 font-bold">蔵書 {totalVol}冊（カード{books.length}枚）・棚3つ・よく使う{pinned.length}冊</p>
          </div>
        </div>
        <nav className="flex flex-wrap gap-2 mt-5" aria-label="タブ">
          {tabs.map(t=><button key={t} className={`tab-btn ${tab===t?"active":""}`} onClick={()=>{setTab(t); setNotice("");}}>{t}{t==="読みたい"&&`（${want.length}）`}{t==="文脈"&&`（${contexts.length}）`}{t==="note下書き"&&`（${drafts.length}）`}</button>)}
        </nav>
      </header>
      {notice && <div className="mt-4 p-3 rounded-lg flex gap-2 items-start" style={{background:"var(--accent-soft)"}}><Check size={18}/><span className="text-sm [overflow-wrap:anywhere]">{notice}</span><button className="ml-auto btn-ghost !py-1" onClick={()=>setNotice("")}>閉じる</button></div>}

      {tab==="棚" && <section className="mt-6">
        <div className="flex flex-wrap gap-2 items-center justify-between">
          <h2 className="serif text-2xl font-bold">棚</h2>
          <button className="btn" onClick={()=>setShowAdd(v=>!v)}><Plus size={16} className="inline mr-1"/>本を追加</button>
        </div>
        {showAdd && <div className="card p-4 mt-4"><h3 className="serif font-bold mb-3">新しい本</h3>
          {addWarn && <div className="p-3 mb-3 rounded border" style={{borderColor:"var(--danger)",color:"var(--danger)"}}><p className="text-sm flex gap-2"><AlertTriangle size={16}/>{addWarn}</p><div className="flex gap-2 mt-2"><button className="btn" onClick={()=>{setAddConfirmed(true); saveAdd({...addForm});}}>それでも追加</button><button className="btn-ghost" onClick={()=>{setAddWarn(null); setAddConfirmed(false);}}>やめる</button></div></div>}
          <div className="grid sm:grid-cols-2 gap-3">
            <Field label="タイトル（必須）"><input value={addForm.title} onChange={e=>setAddForm({...addForm,title:e.target.value})} placeholder="タイトル"/></Field>
            <Field label="著者"><input value={addForm.author} onChange={e=>setAddForm({...addForm,author:e.target.value})}/></Field>
            <Field label="出版社"><input value={addForm.publisher} onChange={e=>setAddForm({...addForm,publisher:e.target.value})}/></Field>
            <Field label="出版年"><input value={addForm.year} onChange={e=>setAddForm({...addForm,year:e.target.value})}/></Field>
            <Field label="ISBN"><input value={addForm.isbn} onChange={e=>setAddForm({...addForm,isbn:e.target.value})}/></Field>
            <Field label="電子版"><select value={addForm.ebook} onChange={e=>setAddForm({...addForm,ebook:e.target.value})}><option>あり</option><option>なし</option><option>要確認</option><option>ありそう</option></select></Field>
            <Field label="棚"><select value={addForm.shelf} onChange={e=>setAddForm({...addForm,shelf:Number(e.target.value)})}><option value={1}>棚1</option><option value={2}>棚2</option><option value={3}>棚3</option></select></Field>
            <Field label="もう一度読むページ"><input value={addForm.pages} onChange={e=>setAddForm({...addForm,pages:e.target.value})} placeholder="p.42 / 第3章"/></Field>
            <Field label="印象に残った文章"><textarea value={addForm.quote} onChange={e=>setAddForm({...addForm,quote:e.target.value})}/></Field>
            <Field label="簡単な感想"><textarea value={addForm.impression} onChange={e=>setAddForm({...addForm,impression:e.target.value})}/></Field>
            <Field label="文脈（カンマ区切り）"><input value={(addForm.contexts||[]).join(", ")} onChange={e=>setAddForm({...addForm,contexts:e.target.value.split(",").map(s=>s.trim()).filter(Boolean)})}/></Field>
            <Field label="関連書籍（カンマ区切り）"><input value={(addForm.related||[]).join(", ")} onChange={e=>setAddForm({...addForm,related:e.target.value.split(",").map(s=>s.trim()).filter(Boolean)})}/></Field>
          </div>
          <div className="flex gap-2 mt-4"><button className="btn" onClick={()=>{ if(!addForm.title.trim()){setNotice("タイトルは必須です。");return;} saveAdd(addForm); }}>保存する</button><button className="btn-ghost" onClick={()=>setShowAdd(false)}>閉じる</button></div>
        </div>}

        <div className="card p-4 mt-5">
          <div className="grid md:grid-cols-4 gap-3">
            <div className="md:col-span-2"><label className="text-xs" style={{color:"var(--muted)"}}>検索（タイトル・著者・出版社）</label><div className="flex gap-2 mt-1"><Search size={18} className="mt-2 shrink-0"/><input value={search} onChange={e=>setSearch(e.target.value)} placeholder="例：行政法、フランス革命"/></div></div>
            <Field label="電子版"><select value={fEbook} onChange={e=>setFEbook(e.target.value)}>{ebookOpts.map(o=><option key={o}>{o}</option>)}</select></Field>
            <Field label="棚"><select value={fShelf} onChange={e=>setFShelf(e.target.value)}><option>すべて</option><option>1</option><option>2</option><option>3</option></select></Field>
            <Field label="表示"><select value={fView} onChange={e=>setFView(e.target.value)}><option>すべて</option><option>よく使うのみ</option><option>重複のみ</option></select></Field>
          </div>
          <p className="text-xs mt-3" style={{color:"var(--muted)"}}>検索結果：{filtered.length}枚</p>
        </div>

        {(search||fEbook!=="すべて"||fShelf!=="すべて"||fView!=="すべて") ? <div className="mt-6"><h3 className="serif font-bold mb-3">検索結果</h3>{filtered.length===0?<p className="card p-6 text-center" style={{color:"var(--muted)"}}>条件に合う本がありません。検索語や絞り込みを変えてみてください。</p>:<div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-3">{filtered.map(b=><BookCard key={b.id} b={b} onClick={()=>setSelectedId(b.id)} selected={selectedId===b.id}/>)}</div>}</div> : <>
          <div className="mt-8"><div className="flex items-baseline gap-2"><h3 className="serif text-xl font-bold">よく使う</h3><span className="text-sm" style={{color:"var(--muted)"}}>{pinned.length}冊</span></div><p className="text-sm mt-1" style={{color:"var(--muted)"}}>何度も手に取る本。ここから読み返しのページへ。</p><div className="grid sm:grid-cols-2 gap-3 mt-3">{pinned.map(b=><BookCard key={b.id} b={b} onClick={()=>setSelectedId(b.id)} selected={selectedId===b.id}/>)}</div></div>
          {seed.shelves.map(s=>{
            const list=books.filter(b=>b.shelf===s.n); const vols=list.reduce((a,b)=>a+volOf(b),0);
            return <div key={s.n} className="mt-8"><button className="w-full flex items-center gap-2 text-left" onClick={()=>setCollapsed({...collapsed,[s.n]:!collapsed[s.n]})}>{collapsed[s.n]?<ChevronRight/>:<ChevronDown/>}<span className="serif text-xl font-bold">棚{s.n}：{s.title}</span><span className="text-sm" style={{color:"var(--muted)"}}>{vols}冊・{list.length}枚</span></button><p className="text-sm ml-7 mt-1" style={{color:"var(--muted)"}}>{s.note}</p>{!collapsed[s.n] && <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-3 mt-3">{list.map(b=><BookCard key={b.id} b={b} onClick={()=>setSelectedId(b.id)} selected={selectedId===b.id}/>)}</div>}</div>
          })}
        </>}

        {selected && !editForm && <article className="card p-5 mt-8" id="detail">
          <div className="flex flex-wrap justify-between gap-3"><div><p className="text-xs" style={{color:"var(--accent)"}}>棚{selected.shelf} ・ 詳細</p><h3 className="serif text-2xl font-bold [overflow-wrap:anywhere]">{selected.title}</h3><p className="text-sm mt-1" style={{color:"var(--muted)"}}>{selected.author} ／ {selected.publisher} ／ {selected.year||"年不明"}</p></div><div className="flex flex-wrap gap-2"><button className="btn-ghost" onClick={()=>setEditForm({...selected})}>編集</button><button className="btn-ghost" onClick={()=>startDraftFromBook(selected)}><PenLine size={14} className="inline mr-1"/>この本で note下書きを作る</button><button className="btn-danger" onClick={()=>setConfirmDelete(selected.id)}>削除</button></div></div>
          {confirmDelete===selected.id && <div className="p-3 mt-3 border rounded" style={{borderColor:"var(--danger)"}}><p className="text-sm">『{selected.title}』を削除しますか？この画面だけの変更です。</p><div className="flex gap-2 mt-2"><button className="btn-danger" onClick={()=>{setBooks(p=>p.filter(b=>b.id!==selected.id)); setSelectedId(null); setConfirmDelete(null); touch();}}>削除する</button><button className="btn-ghost" onClick={()=>setConfirmDelete(null)}>やめる</button></div></div>}
          <div className="grid sm:grid-cols-2 gap-4 mt-5 text-sm">
            <div><p className="font-bold mb-2">書誌</p><p>ISBN：{selected.isbn||"—"}</p><p className="mt-1">電子版：{selected.ebook||"—"}</p>{selected.badge&&<p className="mt-1"><span className="chip">{selected.badge}</span></p>}{selected.volumes&&<p className="mt-1">{selected.volumes}</p>}<label className="flex gap-2 items-center mt-3"><input type="checkbox" className="!w-auto" checked={!!selected.pinned} onChange={()=>{setBooks(p=>p.map(b=>b.id===selected.id?{...b,pinned:!b.pinned}:b)); touch();}}/>よく使う</label></div>
            <div><p className="font-bold mb-2">電子版リンク（外部サイトが新しいタブで開きます）</p><div className="flex flex-wrap gap-2">{["Kindle","Kobo","BookLive","honto"].map(site=>{ const q=encodeURIComponent(selected.title); const href=site==="Kindle"?`https://www.amazon.co.jp/s?k=${q}`:site==="Kobo"?`https://books.rakuten.co.jp/search/?g=000&s=${q}`:site==="BookLive"?`https://booklive.jp/search?word=${q}`:`https://honto.jp/netstore/search_10${q}.html`; return <a key={site} href={href} target="_blank" rel="noopener" className="chip">{site}で『{selected.title}』を調べる ↗</a> })}</div></div>
          </div>
          <div className="mt-5"><p className="font-bold">もう一度読むページ</p><p className="mt-1 text-sm">{selected.pages||"—"}</p></div>
          <div className="mt-4 p-4 rounded" style={{background:"var(--surface2)"}}><p className="text-xs" style={{color:"var(--muted)"}}>印象に残った文章（読み取り専用）</p><p className="serif mt-2 leading-relaxed [overflow-wrap:anywhere]">「{selected.quote||"—"}」</p></div>
          <div className="grid sm:grid-cols-3 gap-4 mt-4 text-sm"><div><p className="font-bold">簡単な感想</p><p className="[overflow-wrap:anywhere]">{selected.impression||"—"}</p></div><div><p className="font-bold">紐づく論考・原稿</p><p className="[overflow-wrap:anywhere]">{(selected.contexts||[]).join("、")||"—"}</p></div><div><p className="font-bold">関連書籍</p><p className="[overflow-wrap:anywhere]">{(selected.related||[]).join("、")||"—"}</p></div></div>
        </article>}
        {editForm && <div className="card p-5 mt-8"><h3 className="serif font-bold text-xl">『{editForm.title}』を編集</h3><div className="grid sm:grid-cols-2 gap-3 mt-4"><Field label="タイトル"><input value={editForm.title} onChange={e=>setEditForm({...editForm,title:e.target.value})}/></Field><Field label="著者"><input value={editForm.author||""} onChange={e=>setEditForm({...editForm,author:e.target.value})}/></Field><Field label="出版社"><input value={editForm.publisher||""} onChange={e=>setEditForm({...editForm,publisher:e.target.value})}/></Field><Field label="出版年"><input value={editForm.year||""} onChange={e=>setEditForm({...editForm,year:e.target.value})}/></Field><Field label="ISBN"><input value={editForm.isbn||""} onChange={e=>setEditForm({...editForm,isbn:e.target.value})}/></Field><Field label="電子版"><select value={editForm.ebook||"要確認"} onChange={e=>setEditForm({...editForm,ebook:e.target.value})}><option>あり</option><option>なし</option><option>要確認</option><option>ありそう</option></select></Field><Field label="棚"><select value={editForm.shelf} onChange={e=>setEditForm({...editForm,shelf:Number(e.target.value)})}><option value={1}>棚1</option><option value={2}>棚2</option><option value={3}>棚3</option></select></Field><Field label="巻数メモ"><input value={editForm.volumes||""} onChange={e=>setEditForm({...editForm,volumes:e.target.value})}/></Field><Field label="引用"><textarea value={editForm.quote||""} onChange={e=>setEditForm({...editForm,quote:e.target.value})}/></Field><Field label="もう一度読むページ"><input value={editForm.pages||""} onChange={e=>setEditForm({...editForm,pages:e.target.value})}/></Field><Field label="感想"><textarea value={editForm.impression||""} onChange={e=>setEditForm({...editForm,impression:e.target.value})}/></Field><Field label="文脈（カンマ区切り）"><input value={(editForm.contexts||[]).join(", ")} onChange={e=>setEditForm({...editForm,contexts:e.target.value.split(",").map(s=>s.trim()).filter(Boolean)})}/></Field><Field label="関連（カンマ区切り）"><input value={(editForm.related||[]).join(", ")} onChange={e=>setEditForm({...editForm,related:e.target.value.split(",").map(s=>s.trim()).filter(Boolean)})}/></Field></div><div className="flex gap-2 mt-4"><button className="btn" onClick={saveEdit}>保存する</button><button className="btn-ghost" onClick={()=>setEditForm(null)}>やめる</button></div></div>}
      </section>}

      {tab==="取り込む" && <section className="mt-6 max-w-[820px]">
        <h2 className="serif text-2xl font-bold">取り込む</h2>
        <div className="mt-4" aria-label="取り込みモード A / B / C">
          <p className="text-sm" style={{color:"var(--muted)"}}>取り込み方を3つから選べます。表示だけの案内で、機能は今のままです。</p>
          <article className="card p-4 mt-3">
            <h3 className="serif font-bold">Google Cloud と Google AI Studio の関係</h3>
            <ul className="text-sm mt-2 leading-relaxed list-disc pl-5 space-y-1">
              <li>Google AI Studio はブラウザの開発ツール（aistudio.google.com）で、Gemini を試して API キーを作る場所。Gemini Developer API のエンドポイントは generativelanguage.googleapis.com。認証は API キー。</li>
              <li>Google Cloud は課金・プロジェクト・IAM などの土台。AI Studio のキーは裏で Google Cloud プロジェクトに紐づいている。別プロジェクトにすれば枠も別になる。</li>
              <li>Vertex AI / Gemini Enterprise Agent Platform は企業向けで、エンドポイントは aiplatform.googleapis.com、認証はサービスアカウント。SLA・コンプライアンスあり。本棚は軽い方（AI Studio / Developer API）でやる。Vertex は重いので使わない。</li>
              <li><strong>重要：</strong>Google Cloud の 90日 $300 クレジットは、Gemini API in AI Studio の料金には使えません。公式にそう書いてある。$300 をあてにして B / C の有料分をまかなう計画は立てない。無料枠か、Gemini API のプリペイド課金プランを使う。</li>
              <li>無料枠：課金アカウントを紐づけないと無料枠のまま。課金なし。有料枠：課金を紐づけると従量課金になり、データは改善に使われない。</li>
            </ul>
          </article>
          <div className="grid md:grid-cols-3 gap-3 mt-3">
            <article className="card p-4">
              <p><span className="chip">A</span></p>
              <h3 className="serif font-bold mt-2">自分でAIに送る（無料）</h3>
              <p className="text-sm mt-2 leading-relaxed">ユーザーが自分の OCR / AI に送って、結果を貼り付ける。開発者側のコストは 0。貼り付け作業あり。A で自分の Google AI Studio の無料キーを使う場合も、同じく Flash-Lite が軽くて向いている。自分の枠は別々に付く。無料枠は 2026年11月時点で大きく絞られている。固定の数字ではなく、自分の AI Studio の画面で確認してください。</p>
            </article>
            <article className="card p-4">
              <p><span className="chip">B</span></p>
              <h3 className="serif font-bold mt-2">一部自動（開発者の Github）</h3>
              <p className="text-sm mt-2 leading-relaxed">写真を開発者の Actions に送る。Actions が Gemini に投げて JSON を返す。ユーザーは JSON を貼って候補を確認する。アプリを使う人はキーを用意しなくて大丈夫。</p>
              <ul className="text-sm mt-2 leading-relaxed list-disc pl-5 space-y-1">
                <li>本棚では Google Cloud の有料サービス（Vertex AI / Compute Engine / Cloud Storage など）は使わない。使うのは Github Actions と Google AI Studio（Gemini Developer API）だけ。</li>
                <li>Google Cloud プロジェクトは、AI Studio の API キーの置き場所としてだけ使う。課金アカウントは紐づけない。$300 のトライアルも使わない。トライアルは Gemini API in AI Studio には使えないので、あてにしない。</li>
                <li>つまり「Google Cloud を使う」＝「プロジェクトを作ってキーを置く」だけ。Cloud のコンソールで何かを作ったり、Cloud に写真を置いたりはしない。写真はユーザーのクラウド（Drive / iCloud / Dropbox / Amazon Photos）にだけ置く。</li>
                <li>将来、有料枠で SLA やデータ利用なしが必要になったら、そのときに Cloud の課金（プリペイド）を検討する。今は無料枠でやる。</li>
              </ul>
              <ul className="text-sm mt-2 leading-relaxed list-disc pl-5 space-y-1">
                <li><strong>AI Studio だけでできます：</strong>本棚の無料枠の使い方は、AI Studio だけの操作でできます。Google Cloud のコンソールを開く必要はありません。</li>
                <li>やることは AI Studio だけで 3つ：① Dashboard / API Keys で API キーを作る（新しいプロジェクトにすれば、裏で Cloud プロジェクトが自動で作られる）、② プロンプトを Playground で試す、③ 画面で上限を確認する。あとは Github の Secrets にキーを貼るだけ。</li>
                <li>Cloud のコンソールが必要になるのは、有料枠にする（課金を紐づける）ときと、Vertex AI を使うときだけ。今の本棚は無料枠なので、Cloud のコンソールは使いません。</li>
              </ul>
              <ul className="text-sm mt-2 leading-relaxed list-disc pl-5 space-y-1">
                <li><strong>プロジェクトを分けるのも、AI Studio だけの操作でできます。</strong>Google Cloud のコンソールを開く必要はありません。</li>
                <li>この画面ではプロジェクトは左上にはありません。左側の MANAGE の中の Dashboard か、左下の一番右の鍵アイコンから行きます。</li>
                <li><strong>AI Studio での手順：</strong>左側の Dashboard を押す → API Keys を開く → Create API key → プロジェクトを選ぶか Create API key in new project を選ぶ。新しいプロジェクトにすれば、裏で Cloud プロジェクトが自動で作られて、無料枠は別々になります。</li>
                <li>左下の鍵アイコンも同じ API Keys の画面へのショートカットです。</li>
                <li>Playground の画面（中央の Build with Gemini 4 Hydrogen など）からはプロジェクトは分けられません。Playground は試す場所で、分ける場所は Dashboard / API Keys です。</li>
                <li>本棚用と「太陽の涙、虚脱の空」用でプロジェクトを分ければ、無料枠は別々になります。</li>
                <li>Cloud のコンソールが必要になるのは、プロジェクト名の変更や削除、請求などの詳細設定のときだけです。無料枠の切り分けだけなら、AI Studio だけで済みます。</li>
              </ul>
              <p className="text-sm mt-2 leading-relaxed">キーはこのアプリ専用のものを新たに作る。別アプリのキーとは使い回さない。Google Cloud のプロジェクトもこのアプリ専用で新たに作る。キーは Github の Secrets（例：GEMINI_API_KEY_BOOKSHELF）に置く。リポジトリには直書きしない。制限は Generative Language API だけにする。HTTP リファラーや IP 制限は Github Actions の IP が変わるので付けない。毎日の読み取りは軽いモデル（gemini-3.5-flash-lite / gemini-3.1-flash-lite）で、重いモデルは使わない。無料枠は 1つのキーで全員分を分け合うので、上限に達したら「今日の無料枠に達しました」と出る。無理に送り直さない。無料枠では Google がコンテンツを改善に使う場合があります。</p>
              <h4 className="font-bold mt-4">無料枠の切り分け</h4>
              <ul className="text-sm mt-2 leading-relaxed list-disc pl-5 space-y-1">
                <li><strong>無料枠はプロジェクト単位で切り分けられます。モデル単位でも分かれます。</strong></li>
                <li>別プロジェクトにすれば、枠は別々です。本棚と「太陽の涙、虚脱の空」は別プロジェクトにすれば、枠を分け合わずに済みます。</li>
                <li>同じプロジェクトでキーを分けても、枠は分かれません。キーだけでは切り分けられません。枠はキーではなくプロジェクトに付きます。</li>
                <li>同じプロジェクトのキーを全員で使う B / C では、使う人ごとの枠は Google 側では分けられません。分けたいなら、使う人ごとに自分のプロジェクト・キーを使う A にするか、アプリ側で 1日10枚までといった独自の上限を付けるしかありません。</li>
                <li>モデルで分けることもできます。B は Flash-Lite、C は Hydrogen のようにモデルを変えれば、モデルごとの枠で分かれます。</li>
              </ul>
            </article>
            <article className="card p-4">
              <p><span className="chip">C</span></p>
              <h3 className="serif font-bold mt-2">全自動（開発者の Github）</h3>
              <p className="text-sm mt-2 leading-relaxed">写真を送ったら、候補の確認まで自動で進み、蔵書に追加まで行く。アプリを使う人はキーを用意しなくて大丈夫。</p>
              <ul className="text-sm mt-2 leading-relaxed list-disc pl-5 space-y-1">
                <li>本棚では Google Cloud の有料サービス（Vertex AI / Compute Engine / Cloud Storage など）は使わない。使うのは Github Actions と Google AI Studio（Gemini Developer API）だけ。</li>
                <li>Google Cloud プロジェクトは、AI Studio の API キーの置き場所としてだけ使う。課金アカウントは紐づけない。$300 のトライアルも使わない。トライアルは Gemini API in AI Studio には使えないので、あてにしない。</li>
                <li>つまり「Google Cloud を使う」＝「プロジェクトを作ってキーを置く」だけ。Cloud のコンソールで何かを作ったり、Cloud に写真を置いたりはしない。写真はユーザーのクラウド（Drive / iCloud / Dropbox / Amazon Photos）にだけ置く。</li>
                <li>将来、有料枠で SLA やデータ利用なしが必要になったら、そのときに Cloud の課金（プリペイド）を検討する。今は無料枠でやる。</li>
              </ul>
              <ul className="text-sm mt-2 leading-relaxed list-disc pl-5 space-y-1">
                <li><strong>AI Studio だけでできます：</strong>本棚の無料枠の使い方は、AI Studio だけの操作でできます。Google Cloud のコンソールを開く必要はありません。</li>
                <li>やることは AI Studio だけで 3つ：① Dashboard / API Keys で API キーを作る（新しいプロジェクトにすれば、裏で Cloud プロジェクトが自動で作られる）、② プロンプトを Playground で試す、③ 画面で上限を確認する。あとは Github の Secrets にキーを貼るだけ。</li>
                <li>Cloud のコンソールが必要になるのは、有料枠にする（課金を紐づける）ときと、Vertex AI を使うときだけ。今の本棚は無料枠なので、Cloud のコンソールは使いません。</li>
              </ul>
              <ul className="text-sm mt-2 leading-relaxed list-disc pl-5 space-y-1">
                <li><strong>プロジェクトを分けるのも、AI Studio だけの操作でできます。</strong>Google Cloud のコンソールを開く必要はありません。</li>
                <li>この画面ではプロジェクトは左上にはありません。左側の MANAGE の中の Dashboard か、左下の一番右の鍵アイコンから行きます。</li>
                <li><strong>AI Studio での手順：</strong>左側の Dashboard を押す → API Keys を開く → Create API key → プロジェクトを選ぶか Create API key in new project を選ぶ。新しいプロジェクトにすれば、裏で Cloud プロジェクトが自動で作られて、無料枠は別々になります。</li>
                <li>左下の鍵アイコンも同じ API Keys の画面へのショートカットです。</li>
                <li>Playground の画面（中央の Build with Gemini 4 Hydrogen など）からはプロジェクトは分けられません。Playground は試す場所で、分ける場所は Dashboard / API Keys です。</li>
                <li>本棚用と「太陽の涙、虚脱の空」用でプロジェクトを分ければ、無料枠は別々になります。</li>
                <li>Cloud のコンソールが必要になるのは、プロジェクト名の変更や削除、請求などの詳細設定のときだけです。無料枠の切り分けだけなら、AI Studio だけで済みます。</li>
              </ul>
              <p className="text-sm mt-2 leading-relaxed">キーはこのアプリ専用のものを新たに作る。別アプリのキーとは使い回さない。Google Cloud のプロジェクトもこのアプリ専用で新たに作る。キーは Github の Secrets（例：GEMINI_API_KEY_BOOKSHELF）に置く。リポジトリには直書きしない。制限は Generative Language API だけにする。HTTP リファラーや IP 制限は Github Actions の IP が変わるので付けない。毎日の読み取りは軽いモデル（gemini-3.5-flash-lite / gemini-3.1-flash-lite）で、重いモデルは使わない。無料枠は 1つのキーで全員分を分け合うので、上限に達したら「今日の無料枠に達しました」と出る。無理に送り直さない。無料枠では Google がコンテンツを改善に使う場合があります。</p>
              <h4 className="font-bold mt-4">無料枠の切り分け</h4>
              <ul className="text-sm mt-2 leading-relaxed list-disc pl-5 space-y-1">
                <li><strong>無料枠はプロジェクト単位で切り分けられます。モデル単位でも分かれます。</strong></li>
                <li>別プロジェクトにすれば、枠は別々です。本棚と「太陽の涙、虚脱の空」は別プロジェクトにすれば、枠を分け合わずに済みます。</li>
                <li>同じプロジェクトでキーを分けても、枠は分かれません。キーだけでは切り分けられません。枠はキーではなくプロジェクトに付きます。</li>
                <li>同じプロジェクトのキーを全員で使う B / C では、使う人ごとの枠は Google 側では分けられません。分けたいなら、使う人ごとに自分のプロジェクト・キーを使う A にするか、アプリ側で 1日10枚までといった独自の上限を付けるしかありません。</li>
                <li>モデルで分けることもできます。B は Flash-Lite、C は Hydrogen のようにモデルを変えれば、モデルごとの枠で分かれます。</li>
              </ul>
            </article>
          </div>
          <p className="text-xs mt-2" style={{color:"var(--muted)"}}>料金の表示はあとで決めるため、ここでは料金ラベルを付けていません。</p>
          <p className="sr-only">開発者リポジトリ：{DEVELOPER_REPO_URL}</p>
        </div>
        <div className="card p-4 mt-4">
          <h3 className="font-bold">Github Actions 経由でAIに送る（B方式・推奨）</h3>
          <p className="text-sm mt-2 leading-relaxed" style={{color:"var(--muted)"}}>アプリは軽いままです。重い処理は Actions 側でやります。写真は処理が終わったら Actions 側で消して、残るのは JSON だけです。写真の原本はユーザーのクラウドにだけ置いておけます。</p>
          <p className="text-sm mt-2 leading-relaxed">AIに送るを押した写真だけ、認識のために外部に送ります。</p>
        </div>

        <div className="card p-4 mt-4">
          <h3 className="font-bold">写真の渡し方</h3>
          <div className="flex flex-wrap gap-2 mt-3" role="tablist" aria-label="写真の渡し方">
            <button type="button" className={photoMode==="file"?"btn !py-2 !px-3 !text-[13px]":"btn-ghost !py-2 !px-3"} aria-pressed={photoMode==="file"} onClick={()=>setPhotoMode("file")}>ファイルを直接選ぶ</button>
            <button type="button" className={photoMode==="cloud"?"btn !py-2 !px-3 !text-[13px]":"btn-ghost !py-2 !px-3"} aria-pressed={photoMode==="cloud"} onClick={()=>setPhotoMode("cloud")}>クラウドのURLを貼る</button>
          </div>
          {photoMode==="file" && <div className="mt-4">
            <input ref={fileRef} className="hidden" type="file" accept="image/*" onChange={e=>handlePhoto(e.target.files?.[0])}/>
            <button className="btn-ghost" onClick={()=>fileRef.current?.click()}><Upload size={15} className="inline mr-1"/>写真を選ぶ</button>
            <p className="text-xs mt-2 leading-relaxed" style={{color:"var(--muted)"}}>Google Drive / iCloud / Dropbox / Amazon Photos のどれからでも、端末のファイル選択画面から選べます。端末のファイル選択画面で、各クラウドの場所を開いて写真を選んでください。</p>
            {photoUrl && <div className="mt-3"><img src={photoUrl} alt="選んだ棚の写真のプレビュー" className="max-h-[320px] w-auto max-w-full object-contain rounded border" style={{borderColor:"var(--line)",background:"var(--surface2)"}}/><p className="text-xs mt-1 [overflow-wrap:anywhere]" style={{color:"var(--muted)"}}>{photoName}</p><p className="text-sm mt-2">ファイルは直接送りません。URLに変換してから送ってください。クラウドに上げた写真の直ダウンロードURLを「クラウドのURLを貼る」で貼ってから送ってください。</p></div>}
          </div>}
          {photoMode==="cloud" && <div className="mt-4">
            <div className="grid sm:grid-cols-[180px_1fr] gap-3">
              <Field label="クラウド"><select value={cloudProvider} onChange={e=>{setCloudProvider(e.target.value); setGhMsg("");}}><option>Google Drive</option><option>iCloud</option><option>Dropbox</option><option>Amazon Photos</option></select></Field>
              <Field label="共有リンクのURL"><input value={cloudUrl} onChange={e=>setCloudUrl(e.target.value)} placeholder="https://…" inputMode="url"/></Field>
            </div>
            {cloudProvider==="Google Drive" && <p className="text-xs mt-2 leading-relaxed" style={{color:"var(--muted)"}}>Google Drive は「リンクを知っている全員」にしておいてください。貼ったリンクから直ダウンロードURLを作ります。</p>}
            {cloudProvider==="Dropbox" && <p className="text-xs mt-2 leading-relaxed" style={{color:"var(--muted)"}}>Dropbox は貼ったリンクの ?dl=0 を ?dl=1 に変換して直ダウンロードURLを作ります。</p>}
            {cloudUnsupported && <p className="text-sm mt-3 p-3 rounded border" style={{borderColor:"var(--danger)",color:"var(--danger)"}}>このリンクは Actions 側から直接落とせません。ファイルを直接選んでください。<button className="btn-ghost !py-1 !px-2 !text-xs ml-2" onClick={()=>setPhotoMode("file")}>ファイルを直接選ぶへ</button></p>}
            {directUrlInfo.note && !cloudUnsupported && <p className="text-sm mt-3">{directUrlInfo.note}</p>}
            {directUrlInfo.direct && <div className="mt-3"><label className="text-xs block mb-1" style={{color:"var(--muted)"}}>直ダウンロードURL</label><input readOnly value={directUrlInfo.direct} aria-label="直ダウンロードURL"/><p className="text-xs mt-1" style={{color:"var(--muted)"}}>このURLを Actions へ送ります。</p></div>}
          </div>}
        </div>

        <div className="card p-4 mt-4">
          <h3 className="font-bold">位置情報</h3>
          <p className="text-sm mt-2 leading-relaxed" style={{color:"var(--muted)"}}>取り込むときに棚と段を選んでください。AIに送るプロンプトにも、左から何番目かを聞く文を入れています。</p>
          <div className="grid sm:grid-cols-2 gap-3 mt-3">
            <Field label="棚"><select value={importShelf} onChange={e=>setImportShelf(Number(e.target.value))}><option value={1}>棚1</option><option value={2}>棚2</option><option value={3}>棚3</option></select></Field>
            <Field label="段"><select value={importRow} onChange={e=>setImportRow(e.target.value)}><option>上段</option><option>中段</option><option>下段</option></select></Field>
          </div>
          <div className="mt-4">
            <label className="text-xs block mb-1" style={{color:"var(--muted)"}}>AIに送るプロンプト（棚{importShelf}・{importRow}）</label>
            <textarea ref={aiPromptRef} rows={4} readOnly value={aiPrompt} aria-label="AIに送るプロンプト"/>
            <button className="btn-ghost mt-2" onClick={copyAiPrompt}><Copy size={14} className="inline mr-1"/>プロンプトをコピーする</button>
          </div>
        </div>

        <div className="card p-4 mt-4">
          <h3 className="font-bold">開発者の Github Actions に送る</h3>
          <p className="text-sm mt-2 leading-relaxed">このアプリは、開発者の Github Actions を使います。あなたは Github アカウントを用意しなくて大丈夫です。写真は開発者の Actions で一時的に処理され、終わったら消えて、結果の JSON だけが返ってきます。写真の原本はあなたのクラウドにだけ残ります。</p>
          <p className="text-xs mt-2" style={{color:"var(--muted)"}}>送るもの：直ダウンロードURL・棚{importShelf}・{importRow}・プロンプト。写真ファイルそのものは送りません。</p>
          <button className="btn mt-3" disabled={ghSending} onClick={sendToActions}>{ghSending?"Actions に送っています…":"Actions に送る"}</button>
          {ghMsg && <p className="text-sm mt-3">{ghMsg}</p>}
        </div>

        <div className="card p-4 mt-4">
          <h3 className="font-bold">結果の受け取り</h3>
          <p className="text-sm mt-2 leading-relaxed" style={{color:"var(--muted)"}}>Actions の結果 JSON を貼ってください。[{`{title, author, publisher, shelf, row, position}`}] の配列でも、AIの返答テキストでも受け取れます。</p>
          <div className="mt-3"><Field label="Actions の結果 JSON を貼る"><textarea rows={8} value={actionsJson} onChange={e=>setActionsJson(e.target.value)} placeholder={'例：\n[{"title":"タイトル","author":"著者","publisher":"出版社","shelf":1,"row":"上段","position":1}]'}/></Field></div>
          <button className="btn mt-3" onClick={buildActionsCandidates}>JSONから候補を作る</button>
          {actionsMsg && <p className="text-sm mt-3">{actionsMsg}</p>}
        </div>
        {actionsCandidates.length>0 && <div className="card p-4 mt-4"><h3 className="font-bold">候補（{actionsCandidates.length}件）</h3><p className="text-xs mt-1" style={{color:"var(--muted)"}}>タイトル・著者・出版社・棚・段・左から何番目は手で直せます。チェックした新規だけ追加されます。</p><div className="space-y-4 mt-3">{actionsCandidates.map((c)=>{ const d=dupFor(c.title,""); const inBooks=!!d.inBooks; const inWant=!!d.inWant; return <div key={c.id} className="border-t pt-3" style={{borderColor:"var(--line)"}}><div className="flex flex-wrap gap-2 items-center"><label className="flex gap-2 items-center text-sm"><input type="checkbox" className="!w-auto" checked={c.checked} disabled={inBooks||inWant} onChange={()=>setActionsCandidates(prev=>prev.map(x=>x.id===c.id?{...x,checked:!x.checked}:x))}/>この本を追加する</label>{c.unparsed&&<span className="chip" style={{color:"var(--danger)",borderColor:"var(--danger)"}}>パースできませんでした</span>}{inBooks?<span className="chip" style={{color:"var(--danger)",borderColor:"var(--danger)"}}>すでに棚にあります（重複）{d.inBooks?`・棚${d.inBooks.shelf}`:""}</span>:inWant?<span className="chip" style={{color:"var(--accent)",borderColor:"var(--accent)"}}>読みたいにあります</span>:<span className="chip" style={{color:"var(--ok)",borderColor:"var(--ok)"}}>新規候補</span>}<button className="btn-ghost !py-1 !px-2 !text-xs ml-auto" onClick={()=>setActionsCandidates(prev=>prev.filter(x=>x.id!==c.id))}>この候補を削除</button></div><div className="grid sm:grid-cols-3 gap-2 mt-2"><div className="field"><label>タイトル</label><input value={c.title} onChange={e=>setActionsCandidates(prev=>prev.map(x=>x.id===c.id?{...x,title:e.target.value}:x))}/></div><div className="field"><label>著者</label><input value={c.author} onChange={e=>setActionsCandidates(prev=>prev.map(x=>x.id===c.id?{...x,author:e.target.value}:x))}/></div><div className="field"><label>出版社</label><input value={c.publisher} onChange={e=>setActionsCandidates(prev=>prev.map(x=>x.id===c.id?{...x,publisher:e.target.value}:x))}/></div><div className="field"><label>棚</label><select value={c.shelf} onChange={e=>setActionsCandidates(prev=>prev.map(x=>x.id===c.id?{...x,shelf:Number(e.target.value)}:x))}><option value={1}>棚1</option><option value={2}>棚2</option><option value={3}>棚3</option></select></div><div className="field"><label>段</label><select value={c.row} onChange={e=>setActionsCandidates(prev=>prev.map(x=>x.id===c.id?{...x,row:e.target.value}:x))}><option>上段</option><option>中段</option><option>下段</option></select></div><div className="field"><label>左から何番目</label><input value={c.position} onChange={e=>setActionsCandidates(prev=>prev.map(x=>x.id===c.id?{...x,position:e.target.value}:x))} placeholder="1"/></div></div></div> })}</div><button className="btn mt-4" onClick={addActionsCandidates}>選んだ本を蔵書に追加</button></div>}

        <div className="card p-4 mt-4">
          <h3 className="font-bold">AIの認識結果を貼り付けて取り込む（手動）</h3>
          <ol className="text-sm mt-2 leading-relaxed list-decimal pl-5 space-y-1">
            <li>本棚の写真をAIチャットに見せる</li>
            <li>下のプロンプトをコピーして一緒に送る</li>
            <li>AIの返答をコピーして下の欄に貼る</li>
          </ol>
          <div className="mt-4"><Field label="AIの返答をそのまま貼る"><textarea rows={8} value={aiPaste} onChange={e=>setAiPaste(e.target.value)} placeholder={"例：\n1. 『タイトル』 著者：名前 / 出版社\n2. 『タイトル』 編：名前 / 出版社"}/></Field></div>
          <div className="flex flex-wrap gap-3 items-end mt-3"><div className="field"><label>追加先の棚</label><select value={aiShelf} onChange={e=>setAiShelf(Number(e.target.value))}><option value={1}>棚1</option><option value={2}>棚2</option><option value={3}>棚3</option></select></div><button className="btn" onClick={buildAiCandidates}>貼り付けから候補を作る</button></div>
          {aiMsg && <p className="text-sm mt-3">{aiMsg}</p>}
        </div>
        {aiCandidates.length>0 && <div className="card p-4 mt-4"><h3 className="font-bold">候補（{aiCandidates.length}件）</h3><p className="text-xs mt-1" style={{color:"var(--muted)"}}>タイトル・著者・出版社は手で直せます。チェックした新規だけ追加されます。</p><div className="space-y-4 mt-3">{aiCandidates.map((c)=>{ const d=dupFor(c.title,""); const inBooks=!!d.inBooks; const inWant=!!d.inWant; return <div key={c.id} className="border-t pt-3" style={{borderColor:"var(--line)"}}><div className="flex flex-wrap gap-2 items-center"><label className="flex gap-2 items-center text-sm"><input type="checkbox" className="!w-auto" checked={c.checked} disabled={inBooks||inWant} onChange={()=>setAiCandidates(prev=>prev.map(x=>x.id===c.id?{...x,checked:!x.checked}:x))}/>この本を追加する</label>{c.unparsed&&<span className="chip" style={{color:"var(--danger)",borderColor:"var(--danger)"}}>パースできませんでした</span>}{inBooks?<span className="chip" style={{color:"var(--danger)",borderColor:"var(--danger)"}}>すでに棚にあります（重複）{d.inBooks?`・棚${d.inBooks.shelf}`:""}</span>:inWant?<span className="chip" style={{color:"var(--accent)",borderColor:"var(--accent)"}}>読みたいにあります</span>:<span className="chip" style={{color:"var(--ok)",borderColor:"var(--ok)"}}>新規候補</span>}<button className="btn-ghost !py-1 !px-2 !text-xs ml-auto" onClick={()=>setAiCandidates(prev=>prev.filter(x=>x.id!==c.id))}>この候補を削除</button></div><div className="grid sm:grid-cols-3 gap-2 mt-2"><div className="field"><label>タイトル</label><input value={c.title} onChange={e=>setAiCandidates(prev=>prev.map(x=>x.id===c.id?{...x,title:e.target.value}:x))}/></div><div className="field"><label>著者</label><input value={c.author} onChange={e=>setAiCandidates(prev=>prev.map(x=>x.id===c.id?{...x,author:e.target.value}:x))}/></div><div className="field"><label>出版社</label><input value={c.publisher} onChange={e=>setAiCandidates(prev=>prev.map(x=>x.id===c.id?{...x,publisher:e.target.value}:x))}/></div></div></div> })}</div><button className="btn mt-4" onClick={addAiCandidates}>選んだ本を蔵書に追加</button></div>}

        <div className="card p-4 mt-4">
          <h3 className="font-bold">写真を見ながら手入力</h3>
          <p className="text-xs mt-1 leading-relaxed" style={{color:"var(--muted)"}}>写真を見て1行ずつ手入力するのが確実です。入力した行は照合してから蔵書に追加します。</p>
          {photoUrl && <img src={photoUrl} alt="手入力用に大きく表示した棚の写真" className="mt-3 max-h-[360px] w-auto max-w-full object-contain rounded border" style={{borderColor:"var(--line)",background:"var(--surface2)"}}/>}
          {!photoUrl && <p className="text-xs mt-2" style={{color:"var(--muted)"}}>先に「ファイルを直接選ぶ」で写真を選んでください。</p>}
          <div className="flex flex-wrap gap-3 items-end mt-3"><div className="field"><label>追加先の棚</label><select value={importShelf} onChange={e=>setImportShelf(Number(e.target.value))}><option value={1}>棚1</option><option value={2}>棚2</option><option value={3}>棚3</option></select></div><button className="btn-ghost" onClick={()=>setManualRows(p=>[...p,{id:`m${Date.now()}-${p.length}`,title:"",author:""}])}>＋1冊分を追加</button></div>
          <div className="space-y-3 mt-3">{manualRows.map((row,idx)=><div key={row.id} className="grid sm:grid-cols-[1fr_1fr_auto] gap-2 items-end"><div className="field"><label>{idx+1}冊目 タイトル</label><input value={row.title} onChange={e=>setManualRows(p=>p.map(x=>x.id===row.id?{...x,title:e.target.value}:x))} placeholder="タイトル"/></div><div className="field"><label>著者</label><input value={row.author} onChange={e=>setManualRows(p=>p.map(x=>x.id===row.id?{...x,author:e.target.value}:x))} placeholder="著者"/></div><div className="flex gap-2"><button className="btn" onClick={()=>addManualRow(row)}>蔵書に追加</button>{manualRows.length>1&&<button className="btn-ghost" onClick={()=>setManualRows(p=>p.filter(x=>x.id!==row.id))}>削除</button>}</div></div>)}</div>
          {manualMsg && <p className="text-sm mt-2">{manualMsg}</p>}
        </div>
        <div className="card p-4 mt-4"><h3 className="font-bold">ISBN手入力</h3><p className="text-sm mt-1" style={{color:"var(--muted)"}}>外部の書誌サービスへの問い合わせはしません。重複だけ確認し、書誌は手入力で補完します。</p><div className="grid sm:grid-cols-2 gap-3 mt-3"><Field label="ISBN（10/13、ハイフン可）"><input value={isbnInput} onChange={e=>setIsbnInput(e.target.value)} placeholder="978-4-0000-0000-0"/></Field><div className="flex items-end"><button className="btn-ghost" onClick={checkIsbn}>重複を確認する</button></div></div>{isbnMsg&&<p className="text-sm mt-2">{isbnMsg}</p>}<div className="grid sm:grid-cols-2 gap-3 mt-3"><Field label="タイトル"><input value={isbnForm.title} onChange={e=>setIsbnForm({...isbnForm,title:e.target.value})}/></Field><Field label="著者"><input value={isbnForm.author} onChange={e=>setIsbnForm({...isbnForm,author:e.target.value})}/></Field><Field label="出版社"><input value={isbnForm.publisher} onChange={e=>setIsbnForm({...isbnForm,publisher:e.target.value})}/></Field><Field label="出版年"><input value={isbnForm.year} onChange={e=>setIsbnForm({...isbnForm,year:e.target.value})}/></Field></div><button className="btn mt-3" onClick={()=>{ if(!isbnForm.title.trim()){setNotice("タイトルを入れてください。");return;} const nb={...emptyBook(1),title:isbnForm.title,author:isbnForm.author,publisher:isbnForm.publisher,year:isbnForm.year,isbn:isbnInput}; setAddForm(nb); setTab("棚"); setShowAdd(true); setNotice("棚タブの追加フォームにISBN手入力の内容を入れました。"); }}>この書誌で追加フォームへ</button></div>
      </section>}

      {tab==="読みたい" && <section className="mt-6">
        <div className="flex flex-wrap justify-between gap-3"><h2 className="serif text-2xl font-bold">読みたい</h2><p className="text-sm self-center" style={{color:"var(--muted)"}}>{want.length}件</p></div>
        {wantWarn && <div className="p-3 mt-4 border rounded" style={{borderColor:"var(--danger)",color:"var(--danger)"}}><p className="text-sm">{wantWarn}</p><div className="flex gap-2 mt-2"><button className="btn" onClick={()=>{setWantWarn(null); setMoveWarn(null);}}>閉じる</button></div></div>}
        <div className="card p-4 mt-4"><h3 className="font-bold">読みたい本を追加</h3>{wantWarn && <div className="mt-2 p-2 rounded border" style={{borderColor:"var(--danger)"}}><p className="text-sm" style={{color:"var(--danger)"}}>{wantWarn}</p><div className="flex gap-2 mt-2"><button className="btn" onClick={()=>{setWantConfirmed(true); setWantWarn(null);}}>それでも追加する</button><button className="btn-ghost" onClick={()=>{setWantWarn(null); setWantConfirmed(false);}}>やめる</button></div></div>}<div className="grid sm:grid-cols-2 gap-3 mt-3"><Field label="タイトル（必須）"><input value={wantForm.title} onChange={e=>setWantForm({...wantForm,title:e.target.value})}/></Field><Field label="著者"><input value={wantForm.author} onChange={e=>setWantForm({...wantForm,author:e.target.value})}/></Field><Field label="価格"><input value={wantForm.price} onChange={e=>setWantForm({...wantForm,price:e.target.value})} placeholder="例：1,100円 / 要確認"/></Field><Field label="リンク"><input value={wantForm.link} onChange={e=>setWantForm({...wantForm,link:e.target.value})} placeholder="https://…"/></Field><Field label="ステータス"><select value={wantForm.status} onChange={e=>setWantForm({...wantForm,status:e.target.value})}><option>読みたい</option><option>読書中</option><option>読了</option></select></Field><Field label="メモ"><input value={wantForm.memo} onChange={e=>setWantForm({...wantForm,memo:e.target.value})}/></Field></div><div className="flex gap-4 mt-3 text-sm"><label className="flex gap-2"><input type="checkbox" className="!w-auto" checked={!!wantForm.prime} onChange={e=>setWantForm({...wantForm,prime:e.target.checked})}/>Prime Reading</label><label className="flex gap-2"><input type="checkbox" className="!w-auto" checked={!!wantForm.ku} onChange={e=>setWantForm({...wantForm,ku:e.target.checked})}/>Kindle Unlimited</label></div><button className="btn mt-4" onClick={()=>{ if(!wantForm.title.trim()){setNotice("タイトルは必須です。");return;} const d=dupFor(wantForm.title,""); if(!wantConfirmed && d.inBooks){ setWantWarn(`『${wantForm.title}』はすでに棚${d.inBooks.shelf}にあります。重複して買いますか？`); return; } setWant(p=>[{...wantForm,id:`w${Date.now()}`},...p]); setWantForm({id:"",title:"",author:"",prime:false,ku:false,price:"",link:"",memo:"",status:"読みたい"}); setWantWarn(null); setWantConfirmed(false); touch(); setNotice("読みたいリストに追加しました。"); }}>追加する</button></div>
        <div className="grid md:grid-cols-2 gap-3 mt-4">{want.map(w=>{ const inShelf=books.find(b=>normTitle(b.title)===normTitle(w.title)); return <article key={String(w.id)} className="card p-4"><div className="flex justify-between gap-2"><h3 className="serif font-bold [overflow-wrap:anywhere]">{w.title}</h3>{inShelf&&<span className="chip shrink-0" style={{color:"var(--accent)",borderColor:"var(--accent)"}}>棚にあり</span>}</div><p className="text-sm mt-1" style={{color:"var(--muted)"}}>{w.author||"著者不明"} ・ {w.price||"価格未記入"}</p><div className="flex flex-wrap gap-2 mt-2">{w.prime&&<span className="chip">Prime Reading</span>}{w.ku&&<span className="chip">Kindle Unlimited</span>}<span className="chip">{w.status}</span></div><p className="text-sm mt-2 [overflow-wrap:anywhere]">{w.memo}</p>{w.link&&<a href={w.link} target="_blank" rel="noopener" className="text-sm underline break-all">リンクを開く ↗</a>}<div className="flex flex-wrap gap-2 mt-3 items-end"><Field label="棚へ移動"><select value={moveShelf[String(w.id)]||1} onChange={e=>setMoveShelf({...moveShelf,[String(w.id)]:Number(e.target.value)})}><option value={1}>棚1</option><option value={2}>棚2</option><option value={3}>棚3</option></select></Field><button className="btn-ghost" onClick={()=>{ const dup=books.find(b=>normTitle(b.title)===normTitle(w.title)); if(dup){ setMoveWarn(`『${w.title}』はすでに棚${dup.shelf}にあります。`); setNotice(`『${w.title}』はすでに棚${dup.shelf}にあります。読みたいからだけ外す場合は削除を使ってください。`); return; } setBooks(p=>[...p,{id:`b${Date.now()}`,shelf:moveShelf[String(w.id)]||1,title:w.title,author:w.author,publisher:"",year:"",isbn:"",ebook:"要確認",impression:w.memo||""}]); setWant(p=>p.filter(x=>x.id!==w.id)); touch(); setNotice(`『${w.title}』を蔵書へ移動しました。`); }}>蔵書に追加</button><button className="btn-ghost" onClick={()=>setWantEdit({...w})}>編集</button><button className="btn-danger" onClick={()=>{setWant(p=>p.filter(x=>x.id!==w.id)); touch();}}>削除</button></div>{moveWarn&&<p className="text-xs mt-2" style={{color:"var(--danger)"}}>{moveWarn}</p>}</article> })}</div>
        {wantEdit && <div className="card p-4 mt-4"><h3 className="font-bold">読みたいを編集</h3><div className="grid sm:grid-cols-2 gap-3 mt-3"><Field label="タイトル"><input value={wantEdit.title} onChange={e=>setWantEdit({...wantEdit,title:e.target.value})}/></Field><Field label="著者"><input value={wantEdit.author||""} onChange={e=>setWantEdit({...wantEdit,author:e.target.value})}/></Field><Field label="価格"><input value={wantEdit.price||""} onChange={e=>setWantEdit({...wantEdit,price:e.target.value})}/></Field><Field label="リンク"><input value={wantEdit.link||""} onChange={e=>setWantEdit({...wantEdit,link:e.target.value})}/></Field><Field label="ステータス"><select value={wantEdit.status||"読みたい"} onChange={e=>setWantEdit({...wantEdit,status:e.target.value})}><option>読みたい</option><option>読書中</option><option>読了</option></select></Field><Field label="メモ"><input value={wantEdit.memo||""} onChange={e=>setWantEdit({...wantEdit,memo:e.target.value})}/></Field></div><div className="flex gap-2 mt-3"><button className="btn" onClick={()=>{setWant(p=>p.map(x=>x.id===wantEdit.id?wantEdit:x)); setWantEdit(null); touch();}}>保存</button><button className="btn-ghost" onClick={()=>setWantEdit(null)}>やめる</button></div></div>}
      </section>}

      {tab==="文脈" && <section className="mt-6">
        <h2 className="serif text-2xl font-bold">文脈</h2><p className="text-sm mt-2" style={{color:"var(--muted)"}}>引用を、書くための文脈と一緒に置いておく場所。</p>
        <div className="card p-4 mt-4"><h3 className="font-bold">引用カードを追加</h3><div className="grid sm:grid-cols-2 gap-3 mt-3"><Field label="引用文"><textarea value={ctxForm.quote} onChange={e=>setCtxForm({...ctxForm,quote:e.target.value})}/></Field><Field label="出典（蔵書から選択）"><select value={ctxForm.source} onChange={e=>setCtxForm({...ctxForm,source:e.target.value})}><option value="">— 選ぶ —</option>{books.map(b=><option key={b.id} value={b.title}>{b.title}</option>)}</select></Field><Field label="出典（自由入力）"><input value={ctxForm.source} onChange={e=>setCtxForm({...ctxForm,source:e.target.value})} placeholder="本・章・ページ"/></Field><Field label="紐づく論考・原稿"><input value={ctxForm.draft||""} onChange={e=>setCtxForm({...ctxForm,draft:e.target.value})}/></Field><Field label="メモ"><textarea value={ctxForm.note||""} onChange={e=>setCtxForm({...ctxForm,note:e.target.value})}/></Field></div><button className="btn mt-3" onClick={()=>{ if(!ctxForm.quote.trim()){setNotice("引用文を入れてください。");return;} setContexts(p=>[{...ctxForm,id:`c${Date.now()}`},...p]); setCtxForm({id:"",quote:"",source:"",draft:"",note:""}); touch(); setNotice("文脈に追加しました。"); }}>追加する</button></div>
        <div className="grid md:grid-cols-2 gap-3 mt-4">{contexts.map(c=><article key={String(c.id)} className="card p-4"><p className="serif leading-relaxed [overflow-wrap:anywhere]">「{c.quote}」</p><p className="text-sm mt-2" style={{color:"var(--muted)"}}>出典：{c.source||"—"}</p><p className="text-sm">紐づく論考・原稿：{c.draft||"—"}</p><p className="text-sm mt-1 [overflow-wrap:anywhere]">{c.note}</p><div className="flex gap-2 mt-3"><button className="btn-ghost" onClick={()=>startDraftFromCtx(c)}>noteへ出す →</button><button className="btn-ghost" onClick={()=>setCtxEdit({...c})}>編集</button><button className="btn-danger" onClick={()=>{setContexts(p=>p.filter(x=>x.id!==c.id)); touch();}}>削除</button></div></article>)}</div>
        {ctxEdit && <div className="card p-4 mt-4"><h3 className="font-bold">文脈を編集</h3><div className="grid sm:grid-cols-2 gap-3 mt-3"><Field label="引用文"><textarea value={ctxEdit.quote} onChange={e=>setCtxEdit({...ctxEdit,quote:e.target.value})}/></Field><Field label="出典"><input value={ctxEdit.source} onChange={e=>setCtxEdit({...ctxEdit,source:e.target.value})}/></Field><Field label="紐づく論考・原稿"><input value={ctxEdit.draft||""} onChange={e=>setCtxEdit({...ctxEdit,draft:e.target.value})}/></Field><Field label="メモ"><textarea value={ctxEdit.note||""} onChange={e=>setCtxEdit({...ctxEdit,note:e.target.value})}/></Field></div><div className="flex gap-2 mt-3"><button className="btn" onClick={()=>{setContexts(p=>p.map(x=>x.id===ctxEdit.id?ctxEdit:x)); setCtxEdit(null); touch();}}>保存</button><button className="btn-ghost" onClick={()=>setCtxEdit(null)}>やめる</button></div></div>}
      </section>}

      {tab==="note下書き" && <section className="mt-6">
        <div className="flex flex-wrap justify-between gap-3"><h2 className="serif text-2xl font-bold">note下書き</h2><span className="chip self-center">公開：非公開（共有は選んで出すだけ）</span></div>
        <div className="grid lg:grid-cols-[1fr_1.2fr] gap-4 mt-4 items-start">
          <div><h3 className="font-bold mb-2">下書き一覧（{drafts.length}件）</h3>{drafts.length===0?<p className="card p-5 text-sm" style={{color:"var(--muted)"}}>まだ下書きがありません。棚の詳細や文脈から「noteへ出す」で作るか、右のエディタで新しく書いてください。</p>:<div className="space-y-3">{drafts.map(d=><article key={d.id} className="card p-4"><h4 className="serif font-bold [overflow-wrap:anywhere]">{d.title}</h4><p className="text-xs" style={{color:"var(--muted)"}}>作成日：{d.created} ・ 出典：{d.source||"—"}</p><p className="text-sm mt-2 line-clamp-3 [overflow-wrap:anywhere]">{d.body||d.quote}</p><div className="flex gap-2 mt-3"><button className="btn-ghost" onClick={()=>{setDraftTitle(d.title); setDraftQuote(d.quote); setDraftSource(d.source); setDraftImpr(d.impression); setDraftBody(d.body); setEditingDraftId(d.id);}}>開く</button><button className="btn-ghost" onClick={()=>{copyRef.current!.value=`${d.title}\n\n「${d.quote}」\n出典：${d.source}\n\n${d.body}`; copyRef.current!.select(); document.execCommand("copy"); setNotice("下書きをコピーしました。");}}>コピー</button><button className="btn-danger" onClick={()=>setDrafts(p=>p.filter(x=>x.id!==d.id))}>削除</button></div></article>)}</div>}</div>
          <div className="card p-4"><h3 className="font-bold">エディタ {editingDraftId?"（編集中）":"（新規）"}</h3><div className="grid gap-3 mt-3"><Field label="タイトル"><input value={draftTitle} onChange={e=>setDraftTitle(e.target.value)}/></Field><Field label="引用"><textarea value={draftQuote} onChange={e=>setDraftQuote(e.target.value)}/></Field><Field label="出典本（蔵書から選択）"><select value={draftSource} onChange={e=>setDraftSource(e.target.value)}><option value="">— 選ぶ —</option>{books.map(b=><option key={b.id} value={b.title}>{b.title}</option>)}</select></Field><Field label="出典（自由入力）"><input value={draftSource} onChange={e=>setDraftSource(e.target.value)}/></Field><Field label="感想"><textarea value={draftImpr} onChange={e=>setDraftImpr(e.target.value)}/></Field><Field label="本文（自由編集可）"><textarea rows={8} value={draftBody} onChange={e=>setDraftBody(e.target.value)} placeholder="ここに本文を書きます。"/></Field></div>
            <div className="p-4 mt-4 rounded" style={{background:"var(--surface2)"}}><p className="text-xs" style={{color:"var(--muted)"}}>プレビュー（書誌が自動で反映されます）</p><h4 className="serif font-bold mt-2 [overflow-wrap:anywhere]">{draftTitle||"（無題）"}</h4>{draftQuote&&<p className="serif mt-2 [overflow-wrap:anywhere]">「{draftQuote}」</p>}{draftSource&&<p className="text-sm mt-1">出典：{draftSource}{(() => { const b=books.find(x=>x.title===draftSource); return b?` ・ ${b.author||""} ／ ${b.publisher||""} ／ ${b.year||""}`:""; })()}</p>}<p className="text-sm mt-3 whitespace-pre-wrap [overflow-wrap:anywhere]">{draftBody||"（本文はまだありません）"}</p>{draftImpr&&<p className="text-sm mt-3 [overflow-wrap:anywhere]">感想：{draftImpr}</p>}</div>
            <div className="flex flex-wrap gap-2 mt-4"><button className="btn" onClick={saveDraft}>保存する</button><button className="btn-ghost" onClick={copyDraft}><Copy size={14} className="inline mr-1"/>コピーする</button><button className="btn-ghost" onClick={()=>{setDraftTitle(""); setDraftQuote(""); setDraftSource(""); setDraftImpr(""); setDraftBody(""); setEditingDraftId(null);}}>新規にクリア</button></div>
            <textarea ref={copyRef} aria-label="コピー用" className="sr-only" readOnly style={{position:"absolute",width:1,height:1,opacity:0}}/>
          </div>
        </div>
      </section>}

      <footer className="mt-12 pt-5 border-t" style={{borderColor:"var(--line)"}}>
        <h2 className="serif font-bold">この画面のデータを扱う</h2><p className="text-sm mt-1" style={{color:"var(--muted)"}}>保存はこの画面の中だけです。JSONで書き出して手元に残すか、読み込んで戻すことができます。</p>
        <div className="flex flex-wrap gap-2 mt-3"><button className="btn" onClick={doExport}><Download size={15} className="inline mr-1"/>JSONエクスポート</button><button className="btn-ghost" onClick={()=>importFileRef.current?.click()}><Upload size={15} className="inline mr-1"/>JSONインポート（ファイル）</button><button className="btn-ghost" onClick={()=>setConfirmReset(v=>!v)}>シードに戻す</button></div>
        <input ref={importFileRef} className="hidden" type="file" accept="application/json,.json" onChange={e=>{ const f=e.target.files?.[0]; if(!f) return; const r=new FileReader(); r.onload=()=>doImport(String(r.result||"")); r.readAsText(f); }}/>
        {confirmReset && <div className="card p-4 mt-3"><p className="text-sm">シード（初期の45カード）に戻しますか？この画面での変更は消えます。</p><div className="flex gap-2 mt-2"><button className="btn-danger" onClick={()=>{setBooks(clone(seed.books)); setWant(clone(seed.want)); setContexts(clone(seed.contexts)); setDrafts([]); setConfirmReset(false); touch(); setNotice("シードに戻しました。");}}>シードに戻す</button><button className="btn-ghost" onClick={()=>setConfirmReset(false)}>やめる</button></div></div>}
        <div className="grid md:grid-cols-2 gap-3 mt-4"><div><label className="text-xs" style={{color:"var(--muted)"}}>書き出したJSON（確認・コピー用）</label><textarea rows={5} value={exportText} readOnly placeholder="「JSONエクスポート」を押すとここに表示されます。"/></div><div><label className="text-xs" style={{color:"var(--muted)"}}>JSONを貼り付けて読み込む</label><textarea rows={5} value={importText} onChange={e=>setImportText(e.target.value)} placeholder='{"books":[…]}'/><button className="btn-ghost mt-2" onClick={()=>doImport(importText)}>貼り付けたJSONを読み込む</button></div></div>
        <p className="text-xs mt-5 flex gap-1 items-center" style={{color:"var(--muted)"}}><BookOpen size={13}/>本棚リサーチ手帳 Rebuild v2 ・ AIに送るを押した写真だけ、認識のために外部に送ります。</p>
      </footer>
    </div>
  </div>
}

function BookCard({b,onClick,selected}:{b:Book;onClick:()=>void;selected:boolean}){
  return <button onClick={onClick} className="card p-4 text-left w-full hover:shadow-sm" style={selected?{borderColor:"var(--accent)",boxShadow:"0 0 0 1px var(--accent)"}:undefined} aria-pressed={selected}>
    <div className="flex justify-between gap-2"><span className="text-[11px] tracking-wider" style={{color:"var(--accent)"}}>棚{b.shelf}{b.pinned?" ・ よく使う":""}</span>{b.badge&&<span className="chip !text-[11px]">{b.badge}</span>}</div>
    <h4 className="serif font-bold leading-snug mt-1 [overflow-wrap:anywhere]">{b.title}{volOf(b)>1&&<span className="text-xs font-normal">（{volOf(b)}巻分・1カード）</span>}</h4>
    <p className="text-xs mt-1 [overflow-wrap:anywhere]" style={{color:"var(--muted)"}}>{b.author||"—"} ／ {b.publisher||"—"}</p>
    {b.quote&&<p className="text-sm mt-2 line-clamp-2 [overflow-wrap:anywhere]">「{b.quote}」</p>}
    <div className="flex flex-wrap gap-2 mt-3 items-center"><EbookChip v={b.ebook}/>{b.pages&&<span className="chip">もう一度：{b.pages}</span>}</div>
  </button>
}
